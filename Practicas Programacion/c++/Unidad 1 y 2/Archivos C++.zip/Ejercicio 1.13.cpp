#include "iostream"
using namespace std;

int main(){
	
	float Galones;
	
	cout << "Por favor ingrese los galones venididos: " << endl;
	cin >> Galones;
	
	cout << "El precio a cobrar es: " << Galones*3.785*8.20 << endl;
	
	return (0);
	
   
}
